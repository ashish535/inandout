<?php
include('../connect.php');
include('../functions/session.php');
include('../functions/header.php');
if ($login_lvl>=6){

echo '<center><div style="margin-top:150px">Not implemented at this time</div></center>';










} else {
//back to home page
header("location: admintest.php");
}
?>