Installation Instructions:

Once files are installed in web server, make sure the main visitor directory and the /includes directory are writable in order for the web install to work.

Navigate to the install directory on your browser by:

	<server information>/install/index.php

The site will check if your directories are writeable.

You will need the following:

Location/IP of server: (usually localhost unless remote connection into MYSQL)
MYSQL username with GRANT privileges to create and modify database.
MYSQL password for the above user
Name of the database (usually called visitor unless this conflicts with a existing DB)

MAKE SURE TO REMOVE THE INSTALL FOLDER AFTER YOU HAVE SUCCESSFUL INSTALLATION.

THANKS!