<?php
echo '<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VIVA Portal</title>
<link href="install.css" rel="stylesheet" type="text/css">';
echo '<div class="main"><center>';
echo '<div class="install_base" align="left">';
echo '<center><h1>VIVA Visitor program installation helper</h1>';
echo 'STEP 2: Necessary Evils</center>';
echo '<p><hr></p>';
echo '<br><h3>Licensing Agreement:</h3>';
echo '<p>MIT License

Copyright (c) 2018 BSconsulting - Baxter Shaffer bstechconsult@gmail.com<br><br>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
<br><br>
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
<br><br>
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.</p>';
echo '<p>BY INSTALLING THIS SOFTWARE, I AGREE TO ALL OF THE ABOVE TERMS WITHOUT RESERVATION.';
echo '<center><a href="install2.php" class="admin_btn">I ACCEPT - NEXT STEP</a></center>';



echo '</div></center></div>';




?>
