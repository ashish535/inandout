<?php
echo '<link href="../css/multiColumnTemplate.css" rel="stylesheet" type="text/css">
<link href="../css/table-style.css" rel="stylesheet" type="text/css">
<!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script type="text/javascript" src="./js/tablesorter/jquery.tablesorter.js"></script>
<script src="sort.js"></script>-->';
?>
