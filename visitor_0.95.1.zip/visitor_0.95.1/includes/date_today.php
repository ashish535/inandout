<?php
//getting today's date
$tday= date(d);
$tmonth= date(m);
$nmonth= date(F);
$tyear = date(Y);

?>
