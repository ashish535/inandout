<?php
include (dirname(__FILE__).'/includes/guest_header.php');
echo '<section>
  <h2 style=text-align:center;>Are you a.....</h2>
<br><br><br><br>
<div style=text-align:center>

<a href="./vol_class.php" class="badge2"style="position:relative;left:-50px;">Volunteer</a>
<a href="./visit_class.php" class="badge3"style="position:relative;left:-10px;">Visitor</a>
</div>
<br><br><br><br><br><br><br><br><!-- <footer class="secondary_header footer">

  </footer>-->
</div>
<center>
<a href="./main.php" style="font-family:arial;font-size:18px;text-align:center;">Return to Main Page</a>
</center></section>';
 ?>
